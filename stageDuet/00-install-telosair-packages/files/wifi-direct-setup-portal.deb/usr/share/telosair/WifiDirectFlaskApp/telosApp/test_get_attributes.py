"""
test_get_attributes -> tests functions from get_attributes.py
"""

import unittest
from unittest.mock import patch
from get_attributes import get_ssid, get_serial, get_mac


class test_get_attributes(unittest.TestCase):

    @patch('get_attributes.subprocess.check_output')
    def test_get_ssid_subprocess(self, mock_sub_check_output):
        get_ssid()
        mock_sub_check_output.assert_called_with(['iwgetid', '-r'])

    def test_get_ssid(self):
        expected_ssid= "TelosAir"
        ssid = get_ssid()
        self.assertEqual(ssid, expected_ssid)

    @patch('get_attributes.open')
    def test_get_serial(self, mock_open):
        get_serial()
        mock_open.assert_called_with('/proc/cpuinfo','r')

    @patch('get_attributes.subprocess.check_output')
    def test_get_mac(self, mock_sub_check_output):
        expected_btaddr = '58:A0:23:F5:0A:1D'
        actual_btaddr = get_mac()
        mock_sub_check_output.assert_called_with(['hciconfig','-a'])
        self.assertTrue(expected_btaddr, actual_btaddr)


if __name__ == "__main__":
    unittest.main()