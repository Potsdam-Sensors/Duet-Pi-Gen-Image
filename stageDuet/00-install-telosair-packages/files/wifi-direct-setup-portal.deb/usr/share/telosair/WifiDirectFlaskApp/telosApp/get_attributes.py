#! /bin/python3

import logging
import subprocess

# Set up logging configuration
logging.basicConfig(level=logging.INFO)

def get_ssid() -> str:
    """
    Function:
        Runs nmcli command to view network SSID.
    Args:
        None
    Returns:
        str: returns str of SSID
    """
    try:
        ssid = subprocess.check_output(['iwgetid', '-r']).decode('utf-8')
        return ''.join(c for c in ssid if c.isprintable())
    except:
        logging.error("Could not view SSID - not connected")
        return "disconnected"


def get_serial() -> str:
    """
    Function:
        Opens cpuinfo file to view the device's serial number.
    Args:
        None
    Returns:
        str: returns str of serial number, if not found, the serial number will be all zeros
    """
    # Extract serial from cpuinfo file
    cpuserial = "0000000000000000"
    try:
        file = open('/proc/cpuinfo', 'r')
        for line in file:
            if line[0:6] == 'Serial':
                cpuserial = line[10:26]
        return cpuserial
    except:
        logging.error("Could not view serial number")
        return cpuserial


def get_mac() -> str:
    """
    Function:
        Checks output from 'hciconfig -a' subprocess command to view Bluetooth MAC address.
    Args:
        None
    Returns:
        str: returns str of Bluetooth MAC address
    """
    btaddr = None
    output = None
    split_output = None
    try:
        output = subprocess.check_output(['hciconfig', '-a'])
        split_output = output.split()
        btaddr = split_output[7].decode()
        return btaddr
    except:
        logging.error("Could not find Bluetooth MAC address")
        return "00:00:00:00:00:00"
