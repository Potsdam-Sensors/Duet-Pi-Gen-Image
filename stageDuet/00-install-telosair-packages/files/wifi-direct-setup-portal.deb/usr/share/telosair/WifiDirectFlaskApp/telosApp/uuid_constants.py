#! /bin/python3

from cryptography.fernet import Fernet
# Encryption Key Constant
# key = Fernet.generate_key()
key = b'CaxDj_ySUgvPH3gySJc0_50n0S6RETYfMMyLZ1BetLg='
FERNET = Fernet(key)

# Service UUIDs
TELOSAIR_ID = '6f067f26-6e66-4a48-b953-33398d6d9240'
DUET_SERIAL = '34898e75-11a9-4b2d-ab08-1f22c3483058'
SSID = '1fd1a015-c36c-41fe-8ba3-acce67e02312'
SSID_PW = '551766a6-a45e-4493-a027-1aef60aabafc'
