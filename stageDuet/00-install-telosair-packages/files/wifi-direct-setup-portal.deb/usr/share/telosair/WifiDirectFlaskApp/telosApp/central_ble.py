import asyncio
from bleak import BleakClient, BleakScanner, BleakError
import logging
import uuid_constants

# Set up logging configuration
logging.basicConfig(level=logging.INFO)

# Create a Dictionary for all the Duet Peripherals
device_dict = {}

async def find_peripherals() -> dict:
    """
    Function:
        Uses Bleak Scanner and Client to find all peripheral TelosAir devices and
        creates a dictionary to store the device information
    Args:
        None
    Returns:
        Dict: returns a dictionary of all the discovered TelosAir peripherals
    """
    # start device discovery
    devices = await BleakScanner.discover(return_adv=True)

    device = None
    serial_number = None
    ssid = None

    # read ssid and sn from each TelosAir Duet found
    if devices is not None:
        for device, data in devices.values():
            if data[0] == "TelosAir Service":
                try:
                    client = BleakClient(device)
                    await client.connect()

                    serial_number = await client.read_gatt_char(uuid_constants.DUET_SERIAL)
                    ssid = await client.read_gatt_char(uuid_constants.SSID)

                    device_dict[str(
                        device.address)] = "telosair-duet", serial_number.decode(), ssid.decode()
                except BleakError as be:
                    logging.error(be)

    return device_dict


async def connect_peripheral_to_wifi(btaddr: str, netInfo: str) -> None:
    """
    Function:
        Uses Bleak Scanner and Client to find and connect to a peripheral and write to it
        the SSID and password of the new network to connect to. 
        Encrypts the network info for security across bluetooth connection.
    Args:
        str (btaddr): a str of the peripheral's bluetooth address
        str (netInfo): a str of the SSID and password to write to the peripheral's characteristic
    Returns:
        None
    """
    # encrypt outgoing write request
    encryptData = uuid_constants.FERNET.encrypt(netInfo.encode())

    device = await BleakScanner.find_device_by_address(btaddr)
    client = BleakClient(device)

    # connect to the peripheral and write encrypted network info to its appropiate characteristic
    try:
        await client.connect()
        await client.write_gatt_char(uuid_constants.SSID_PW, bytearray(encryptData), response=True)
    except BleakError as be:
        logging.error(be)


"""
MANUAL TESTING - UNCOMMENT FOR EITHER FUNCTON 
    - be sure to have peripheralBLE devices running
"""

# Uncomment the following block:
# devices = asyncio.run(find_peripherals())
# for key, value in devices.items():
# logging.info(f"{key}: {value}")

# (info) view sys logs on central device (dictionary of devices) and peripheral device (read requests from central)

# Uncomment the following line:
# asyncio.run(connect_peripheral_to_wifi("1A:2B:3C:4D:5E:6E", "Network+password"))

# (info) must be in the format, connect_to_peripheral("00:00:00:00:00:00", "{SSID}+{password}")
# (info) then check either peripheralBLE logs or WiFi connection status on peripheral device
