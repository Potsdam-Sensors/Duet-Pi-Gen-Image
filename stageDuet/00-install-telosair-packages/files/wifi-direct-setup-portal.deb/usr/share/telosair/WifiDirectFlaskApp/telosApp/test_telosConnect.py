import unittest
from unittest.mock import patch, mock_open
from telos_connect import app, scan_networks, signalStrength, connect_to_wifi, shutdown_server, create_status_file, index, connect_peripheral, find_peripherals


class Test_telos_connect(unittest.TestCase):
    def setUp(self) -> None:
        self.app = app
        self.client = self.app.test_client()

    @patch('telos_connect.subprocess.run')
    def test_scan_networks(self, mock_subprocess_run):
        """Test scanning for networks."""
        mock_subprocess_run.return_value.stdout = (
            'ESSID:"Network1"\n'
            'Encryption Key:on\n'
            'Signal level=-60 dBm\n'
            'ESSID:"Network2"\n'
            'Encryption Key:off\n'
            'Signal level=-80 dBm\n'
        )

        networks = scan_networks()
        expected_networks = [{'ssid': 'Network1', 'encryption': True,
                              'signal': 'Strong'},
                             {'ssid': 'Network2', 'encryption': False,
                              'signal': 'Weak'}]

        self.assertEqual(networks, expected_networks)

    def test_signalStrength(self):
        """Test signal strength classification"""
        self.assertEqual(signalStrength("-80"), "Weak")
        self.assertEqual(signalStrength("-70"), "Good")
        self.assertEqual(signalStrength("-65"), "Strong")

    @patch('telos_connect.subprocess.run')
    def test_connect_to_wifi(self, mock_subprocess_run):
        """Test connecting to wifi"""
        mock_subprocess_run.return_value.stderr = b''
        mock_subprocess_run.return_value.stdout = b'Success'
        connect_to_wifi('test_ssid', 'test_password')
        mock_subprocess_run.assert_called_once_with(['nmcli', 'dev', 'wifi',
                                                     'connect', 'test_ssid',
                                                     'password', 'test_password'],
                                                    capture_output=True)

    @patch('telos_connect.os._exit')
    @patch('telos_connect.time.sleep')
    def test_shutdown_server(self, mock_sleep, mock_exit):
        """Test shutting down Flask server"""
        shutdown_server()
        mock_sleep.assert_called_once_with(5)
        mock_exit.assert_called_once_with(0)

    @patch('telos_connect.os.path.join')
    def test_create_status_file(self, mock_join_path, mock_open):
        mock_file = 'testing.txt'
        mock_path = '/tmp/'
        mock_join_path.return_value = '/tmp/testing.txt'
        mock_file_path = create_status_file(mock_file)
        mock_join_path.assert_called_once_with(mock_path, mock_file)
        mock_open.assert_called_once_with(mock_file_path, 'x')

    @patch('telos_connect.scan_networks')
    def test_index_get(self, mock_scan_networks):
        """Test GET request for index route."""
        mock_scan_networks.return_value = [
            {'ssid': 'Network1', 'encryption': 'True', 'signal': 'Strong'}]
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Network1', response.data)

    @patch('telos_connect.asyncio.run')
    @patch('telos_connect.render_template')
    def test_index_post(self, mock_render_template, mock_asyncio_run):
        """Test POST request for index route."""
        mock_render_template.return_value = "Redirecting..."
        response = self.client.post(
            '/', data={'ssid': 'test_ssid', 'password': 'test_password'})
        self.assertEqual(response.status_code, 200)
        mock_render_template.assert_called_once_with(
            'redirect.html')


if __name__ == '__main__':
    unittest.main()
