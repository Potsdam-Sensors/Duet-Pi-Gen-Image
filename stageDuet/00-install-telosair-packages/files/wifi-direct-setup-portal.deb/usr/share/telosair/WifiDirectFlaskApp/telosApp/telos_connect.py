from flask import Flask, request, render_template, Response
import re
import time
import os
import json
import subprocess
import logging
import string
import asyncio
from typing import Optional, Dict, List
from central_ble import find_peripherals, connect_peripheral_to_wifi
from get_attributes import get_mac, get_serial, get_ssid

# Initialize the Flask application.
app = Flask(__name__)
logging.basicConfig(level=logging.INFO)


GET_METHOD_FLAG = "get_status"
POST_METHOD_FLAG = "post_status"
CONNECTED_FLAG = "connected"
NO_CONNECTION_FLAG = "noConn"

TEMP_FOLDER_PATH = "/tmp/"


# Compile regular expressions to find network SSID, encryption status,
# and signal level
ssid_pattern = re.compile(r'ESSID:"([^"]+)"')
encryption_pattern = re.compile(r'Encryption key:(on|off)')
signal_pattern = re.compile(r'Signal level=(-\d+) dBm')


def scan_networks() -> List[Dict[str, Optional[str]]]:
    """
    Runs a subprocess to capture SSID, encryption type and signal
    strength in dBm from all surrounding networks.

    Returns:
        list: List of dictionaries each containing key value pairs 
        detailing network information; one dictionary per network.
    """
    try:
        result = subprocess.run(
            ['sudo', 'iwlist', 'wlan0', 'scan'], capture_output=True, text=True)
        output = result.stdout

        # Find all matches to the output
        ssids = ssid_pattern.findall(output)
        encryptions = encryption_pattern.findall(output)
        signals = signal_pattern.findall(output)

        # catch ssid, encryption, or signal length mismatch and return empty list
        if not (len(ssids) == len(encryptions) == len(signals)):
            logging.error(
                "Mismatch in length of ssids, encryptions, or signals.")
            return []

        networks = []
        seen_ssids = set()

        def clean_ssid(ssid: str) -> str:
            """Cleans the SSID of non-printable characters if necessary."""
            cleaned = ''.join(c if c in string.printable and c != "\x00"
                              else '?' for c in ssid)
            return cleaned

        # Populate the list of networks
        for i in range(len(ssids)):
            ssid = clean_ssid(ssids[i])
            if ssid in seen_ssids:
                continue
            seen_ssids.add(ssid)
            network = {
                'ssid': ssid,
                'encryption': encryptions[i] == 'on',
                'signal': signalStrength(signals[i])
            }
            networks.append(network)
        return networks

    except Exception as e:
        logging.info(f"Error scanning for networks: {e}")
        return []


def signalStrength(strength: str) -> str:
    """
    Classifies the signal strength of a network as "Weak", "Good",
    or "Strong".

    Args:
        string (strength): String value of signal strength.

    Returns:
        string: "Weak" for strength equal to or below -75, "Good" for
        strength between -75 and -65, otherwise "Strong" connection.
    """
    strength = int(strength)
    if strength <= -75:
        return "Weak"
    elif -75 < strength < -65:
        return "Good"
    else:
        return "Strong"


def connect_to_wifi(ssid: str, password: Optional[str]) -> None:
    """
    Runs nmcli command to connect the device to a network specified by
    the selected SSID and password.

    Args:
        string (ssid): SSID of the desired network.
        string (password): Password for the specified SSID.

    Returns:
        Bool: returns False bool if network connection fails, otherwise calls 
        server_shutdown().
    """
    logging.info("Connecting to requested network")
    connection_command = ['nmcli', 'dev', 'wifi', 'connect', ssid]
    if password:
        connection_command.extend(["password", password])
    result = subprocess.run(connection_command, capture_output=True)
    if result.stdout:
        create_status_file(CONNECTED_FLAG)
    if result.stderr:
        create_status_file(NO_CONNECTION_FLAG)
        logging.info(
            f"Error: Failed to connect to the network: {result.stderr.decode()}")
        os._exit(1)
    logging.info(f"Success: {result.stdout.decode()}")
    shutdown_server()


def shutdown_server() -> None:
    """
    Function to shutdown flask webpage server supporting wifi 
    configuration for Telos Air Duet.
    """
    logging.info("Shutting down in 5s.")
    time.sleep(5)
    logging.info("Shutdown.")
    subprocess.run(['systemctl', 'start', 'peripheral-ble.service'])
    os._exit(0)


def create_status_file(file_name: str) -> str:
    """
    Creates a status file with the given file name in the temporary folder path.

    Args:
        file_name (str): The name of the status file to create.

    Returns:
        str: The full path to the created status file.

    """
    file_path = os.path.join(TEMP_FOLDER_PATH, file_name)
    try:
        with open(file_path, 'x'):
            logging.info(f"File {file_path} created.")
    except FileExistsError:
        logging.info(f"File {file_path} already exists.")
    return file_path


@app.route('/', methods=['GET', 'POST'])
def index() -> str:
    """
    Handles requests from Flask HTML webpage.

    Returns:
        Renders the main Flask webpage "Gui.html" for the user. If the user
        submits their network credentials, this function renders a redirect
        page then calls connect_to_wifi function.
    """
    if request.method == 'POST':
        # handles post request
        ssid = request.form.get('ssid')
        password = request.form.get('password')
        dev_list = request.form.get('selectedDevices')

        logging.info(
            f"Form data received - ssid: {ssid}, password: {password}, selectedDevices: {dev_list}")

        # parse device list from JSON
        dev_list = json.loads(dev_list)
        logging.info(f"Parsed device list: {dev_list}")

        # render the connection in progress page
        render_con_in_prog_page = Response(
            render_template("redirect.html"))

        # create status file for POST method
        create_status_file(POST_METHOD_FLAG)

        @render_con_in_prog_page.call_on_close
        def on_close() -> None:
            """
            Calls connect_to_wifi function only after main returns
            the redirect to the connection in progress page.
            """
            connect_this_device = False
            this_MAC = get_mac()

            # connect devices to WiFi
            for device in dev_list:
                if device == this_MAC:
                    connect_this_device = True
                else:
                    logging.info("Connecting peripheral device to WiFI")
                    asyncio.run(connect_peripheral_to_wifi(
                        device, ssid + "+" + password))

            # connect hosting device if necessary
            if connect_this_device:
                logging.info("Connecting this device to WiFi")
                connect_to_wifi(ssid, password)

        logging.info("Redirecting user to connection in progress page")
        return render_con_in_prog_page

    # handle GET request
    subprocess.run(["systemctl", "stop", "peripheral-ble.service"])

    # create status file for GET method
    create_status_file(GET_METHOD_FLAG)

    # scan for available networks and find peripherals
    networks = scan_networks()
    device_dict = asyncio.run(find_peripherals())
    my_device = {}

    # prepare device information
    my_device[get_mac()] = "(this device)", get_serial(), get_ssid()

    # render the main Flask webpage
    return render_template("Gui.html", networks=networks, device_dict=device_dict, my_device=my_device)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
