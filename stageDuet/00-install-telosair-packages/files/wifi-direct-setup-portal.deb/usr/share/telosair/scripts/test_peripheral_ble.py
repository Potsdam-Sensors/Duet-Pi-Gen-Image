"""
test_peripheral_ble -> tests synchronous functions from peripheral_ble.py
"""

import unittest
import uuid_constants
from unittest.mock import patch
from peripheral_ble import get_ssid, get_serial, connect_to_wifi, read_request, write_request, create_status_file, stop_wifi_services


class test_peripheral_ble(unittest.TestCase):

    @patch('peripheral_ble.subprocess.check_output')
    def test_get_ssid_subprocess(self, mock_sub_check_output):
        get_ssid()
        mock_sub_check_output.assert_called_with(['iwgetid', '-r'])

    def test_get_ssid(self):
        expected_ssid = "TelosAir"
        ssid = get_ssid()
        self.assertEqual(ssid, expected_ssid)

    @patch('peripheral_ble.open')
    def test_get_serial(self, mock_open):
        get_serial()
        mock_open.assert_called_with('/proc/cpuinfo', 'r')

    @patch('peripheral_ble.open')
    @patch('peripheral_ble.os.path.join')
    def test_create_status_file(self, mock_join_path, mock_open):
        mock_file = 'testing.txt'
        mock_path = '/tmp/'
        mock_file_path = create_status_file(mock_file)
        mock_join_path.assert_called_with(mock_path, mock_file)
        mock_open.assert_called_with(mock_file_path, 'x')

    # Parker's implementation
    @patch('peripheral_ble.subprocess.run')
    def test_connect_to_wifi(self, mock_subprocess_run):
        """Test connecting to wifi"""
        mock_subprocess_run.return_value.stderr = b''
        mock_subprocess_run.return_value.stdout = b'Success'
        connect_to_wifi('test_ssid', 'test_password')
        mock_subprocess_run.assert_called_with(['nmcli', 'dev', 'wifi',
                                                'connect', 'test_ssid',
                                                'password', 'test_password'],
                                               capture_output=True)

    @patch('peripheral_ble.GATTCharacteristicProperties')
    def test_read_request(self, mock_characteristic):
        value = read_request(mock_characteristic)
        self.assertEqual(value.return_value, mock_characteristic.value())

    @patch('peripheral_ble.GATTCharacteristicProperties')
    def test_write_request(self, mock_characteristic):
        mock_info = "HELLO+WORLD"
        # pass in a mock encrypted message
        mock_enc = (uuid_constants.FERNET).encrypt(mock_info.encode())
        write_request(mock_characteristic, bytearray(mock_enc))
        # test if characteristic value was updated
        self.assertEqual(mock_characteristic.value, mock_enc)
        # test decrypt
        mock_dec = (uuid_constants.FERNET).decrypt(
            bytes(mock_characteristic.value)).decode()
        self.assertEqual(mock_dec, mock_info)

    @patch('peripheral_ble.check_service_status')
    @patch('peripheral_ble.stop_service')
    def test_stop_wifi_services(self, mock_stop_service, mock_check_service_status):
        stop_wifi_services()
        mock_stop_service.assert_called_with("wifi-app.service")
        # mock_stop_service.assert_called_with("wifi-config-app.service")
        # mock_stop_service.assert_called_with("ensure-wifi.service")
        mock_check_service_status.assert_called_with("wifi-app.service")

        
if __name__ == "__main__":
    unittest.main()
