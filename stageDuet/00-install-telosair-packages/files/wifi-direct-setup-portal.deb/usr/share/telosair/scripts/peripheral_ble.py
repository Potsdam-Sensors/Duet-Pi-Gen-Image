#! /bin/python3

import asyncio
import logging
import os
import subprocess
import sys
import time
import uuid_constants

from bless import (
    BlessServer,
    BlessGATTCharacteristic,
    GATTCharacteristicProperties,
    GATTAttributePermissions,
)
from ensure_wifi import stop_service, check_service_status
from typing import Any

# Set up logging configuration
logging.basicConfig(level=logging.INFO)

trigger = asyncio.Event()

# global network variables for when connecting to a new network
device_ssid = None
device_pw = None

# tmp folder and file for LED implementation
DONE_NET_CONFIG_FLAG = "done"
TEMP_FOLDER_PATH = "/tmp/"


def get_ssid() -> str:
    """
    Function:
        Runs nmcli command to view network SSID.
    Args:
        None
    Returns:
        str: returns str of SSID
    """
    try:
        ssid = subprocess.check_output(['iwgetid', '-r']).decode('utf-8')
        return ''.join(c for c in ssid if c.isprintable())
    except:
        logging.error("Could not view SSID")
        return "disconnected"


def get_serial() -> str:
    """
    Function:
        Opens cpuinfo file to view the device's serial number.
    Args:
        None
    Returns:
        str: returns str of serial number, if not found, the serial number will be all zeros
    """
    cpuserial = "0000000000000000"

    try:
        file = open('/proc/cpuinfo', 'r')
        for line in file:
            if line[0:6] == 'Serial':
                cpuserial = line[10:26]
        return cpuserial
    except:
        logging.error("Could not view serial number")
        return cpuserial


def create_status_file(file_name: str) -> str:
    """
    Function:
        Creates a file location for incoming file in the /tmp folder. Used
        for LED implementations
    Args:
        string (file_name): name of the temporary .txt file
    Returns:
        str (file_path): the path of the tmp file - /tmp/file_name
    """
    file_path = os.path.join(TEMP_FOLDER_PATH, file_name)
    try:
        with open(file_path, 'x'):
            logging.info(f"File {file_path} created.")
    except FileExistsError:
        logging.info(f"File {file_path} already exists.")
    return file_path


def connect_to_wifi(ssid: str, password: str) -> bool:
    """
    Function:
        Runs nmcli command to connect the device to a network specified by
        the selected SSID and password.
    Args:
        string (ssid): SSID of the desired network.
        string (password): Password for the specified SSID.
    Returns:
        Bool: returns False bool if network connection fails
    """
    subprocess.run(['nmcli', 'dev', 'wifi'])

    logging.info("Connecting to requested network")
    connection_command = ['nmcli', 'dev', 'wifi', 'connect', ssid]

    if password:
        connection_command.extend(["password", password])

    result = subprocess.run(connection_command, capture_output=True)
    if result.stderr:
        logging.info(
            f"Error: Failed to connect to the network: {result.stderr.decode()}")
        return False
    
    logging.info(f"Success: {result.stdout.decode()}")


def read_request(characteristic: BlessGATTCharacteristic, **kwargs) -> bytearray:
    """
    Function:
        Read request function for the GATT server - reads the specified GATT characteristic.
    Args:
        BlessGATTCharacteristic (characteristic): the value of the GATT characteristic
    Returns:
        Bytearray: returns the value of the GATT characteristic
    """
    logging.info(f"Central req:'{(characteristic.value).decode()}' | Sent")
    return characteristic.value


def write_request(characteristic: BlessGATTCharacteristic, value: Any, **kwargs) -> None:
    """
    Function:
        Write request function for the GATT server - writes to the specified GATT characteristic.
        Unlike typical write requests, the characteristic.value will consist of the new 
        SSID and password to connect to WiFi with.
        Decrypts the incoming write request.
    Args:
        BlessGATTCharacteristic (characteristic): the value of the GATT characteristic
    Returns:
        None
    """
    global device_ssid
    global device_pw

    try:
        characteristic.value = value
        logging.info("Received WiFi details")

        # decrypt incoming write request
        data = (uuid_constants.FERNET).decrypt(
            bytes(characteristic.value)).decode()
        
        # extract SSID and PW from the data
        space = data.index('+')
        device_ssid = data[:space]
        device_pw = data[(space+1):]

        # set trigger to true so that server can continue and restart
        trigger.set()
    except:
        logging.error("Details provided were not in proper format")


async def create_server() -> BlessServer:
    """
    Function:
        Creates a BlessServer that will advertise its services and the subsequent characteristics through BLE.
        The following characteristics are also defined for the service:
            - Device Serial Number | Read Only
            - Device Network SSID | Read Only
            - SSID and Password for New Connection | Write Only
    Args:
        None
    Returns:
        BlessServer: returns a server used for BLE advertisement
    """
    try:
        # Create a new advertising server
        my_service_name = "TelosAir Service"
        server = BlessServer(name=my_service_name)
        server.read_request_func = read_request
        server.write_request_func = write_request

        # Add a custom service w/ UUID
        await server.add_new_service(uuid_constants.TELOSAIR_ID)

        # Characteristic for the duet's serial number | read only
        await server.add_new_characteristic(
            uuid_constants.TELOSAIR_ID, 
            uuid_constants.DUET_SERIAL, 
            (GATTCharacteristicProperties.read | GATTCharacteristicProperties.indicate), 
            bytearray(get_serial().encode()), 
            GATTAttributePermissions.readable
        )

        # Characteristic for the duet's SSID its connected to | read only
        await server.add_new_characteristic(
            uuid_constants.TELOSAIR_ID, 
            uuid_constants.SSID, 
            (GATTCharacteristicProperties.read | GATTCharacteristicProperties.indicate), 
            bytearray(get_ssid().encode()), 
            GATTAttributePermissions.readable
        )

        # Characteristic to change duet's WiFi network | write
        await server.add_new_characteristic(
            uuid_constants.TELOSAIR_ID, 
            uuid_constants.SSID_PW, 
            (GATTCharacteristicProperties.write | GATTCharacteristicProperties.indicate), 
            None, 
            GATTAttributePermissions.writeable
        )

        return server
    except:
        logging.error("There was an error when setting up the GATT server.")


def stop_wifi_services() -> None:
    """
    Function:
        Called when wifi app services are no longer needed -- stops all wifi app services
    Args:
        None
    Returns:
        None
    """
    stop_service("wifi-app.service")
    while check_service_status('wifi-app.service') != "inactive":
        time.sleep(1)

    stop_service("wifi-config-app.service")
    while check_service_status('wifi-config-app.service') != "inactive":
        time.sleep(1)

    stop_service("ensure-wifi.service")
    while check_service_status('ensure-wifi.service') != "inactive":
        time.sleep(1)


async def main() -> None:
    """
    Function:
        Main function starts the BlessServer which advertises and waits for incoming read/write requests
        made by the central device. Attempts to connect to WiFi when passed ssid and password.
    Args:
        None
    Returns:
        None
    """
    while True:
        try:
            # clear any existing asyncio.Event() notifications
            trigger.clear()

            server = await create_server()
            await server.start()

            logging.info(
                "Serial Number: " + server.get_characteristic(uuid_constants.DUET_SERIAL).value.decode())
            logging.info(
                "SSID: " + server.get_characteristic(uuid_constants.SSID).value.decode())
            logging.info("Advertising...")
            logging.info("Waiting for an update in WiFi details...")

            # set trigger to false while write_request waits for incoming WiFi details
            await trigger.wait()

            # update and notify the change of the characteristic's value
            logging.info("Updating and stopping server...")
            server.update_value(uuid_constants.TELOSAIR_ID,
                                uuid_constants.SSID_PW)
            
            await asyncio.sleep(5)
            await server.stop()
        except:
            logging.error("There was an error while advertising...")
            sys.exit(1)

        # attempt to connect to wifi - if successful, stop wifi-app services; if not, continue the services
        if connect_to_wifi(device_ssid, device_pw) != False:
            create_status_file(DONE_NET_CONFIG_FLAG)
            stop_wifi_services()


if __name__ == "__main__":
    asyncio.run(main())
