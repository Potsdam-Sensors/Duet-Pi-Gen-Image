#! /bin/python3

import subprocess
import time
import socket
import dbus
import logging
import os

# Set up logging configuration
logging.basicConfig(level=logging.INFO)


# Constants for various timeouts and intervals.
TIME_WAIT_INITIAL = 60  # Initial wait time for network connection
"""(in seconds)"""
TIME_WAIT_ATTEMPT = 15  # Wait time between connection attempts
"""(in seconds)"""
HOTSPOT_INACTIVE = 600  # Wait time before considering hotspot inactive
"""(in seconds)"""

# Network interface and service name constants
SERVICE_NAME = "wifi-config-app.service"


CONNECTED_FLAG = "connected"
NO_CONNECTION_FLAG = "noConn"
DONE_NET_CONFIG_FLAG = "done"
TEMP_FOLDER_PATH = "/tmp/"


# Lambda function to get the serial number
def get_serial_number(): return subprocess.check_output(
    "cat /proc/cpuinfo | grep Serial | awk '{print $NF}'", shell=True).decode().strip()


# Lambda function to get the system bus
def get_system_bus(): return dbus.SystemBus()

# Lambda function to get the systemd object


def get_systemd(system_bus): return system_bus.get_object(
    'org.freedesktop.systemd1', '/org/freedesktop/systemd1')

# Lambda function to get the manager interface


def get_manager(systemd): return dbus.Interface(
    systemd, 'org.freedesktop.systemd1.Manager')


def check_service_status(service_name: str) -> str:
    """
    Check the status of the systemd service.

    Args:
        service_name (str): The name of the service to check.

    Returns:
        str: The active state of the service.
    """
    system_bus = get_system_bus()
    systemd = get_systemd(system_bus)
    manager = get_manager(systemd)
    service_unit_path = manager.LoadUnit(service_name)
    service_unit = system_bus.get_object(
        'org.freedesktop.systemd1', service_unit_path)
    service_properties = dbus.Interface(service_unit, dbus.PROPERTIES_IFACE)
    active_state = service_properties.Get(
        'org.freedesktop.systemd1.Unit', 'ActiveState')
    return active_state



def start_service(service_name: str) -> None:
    """
    Starts a systemd service.

    Args:
        service_name (str): The name of the service to start.
    """
    system_bus = get_system_bus()
    systemd = get_systemd(system_bus)
    manager = dbus.Interface(systemd, 'org.freedesktop.systemd1.Manager')
    manager.StartUnit(service_name, 'replace')
    logging.info(f"{service_name} has been started.")


def stop_service(service_name: str) -> None:
    """
    Stops a systemd service.

    Args:
        service_name (str): The name of the service to stop.
    """
    system_bus = get_system_bus()
    systemd = get_systemd(system_bus)
    manager = dbus.Interface(systemd, 'org.freedesktop.systemd1.Manager')
    manager.StopUnit(service_name, 'replace')
    logging.info(f"{service_name} has been halted.")


def check_internet_connection(host: str = "8.8.8.8", port: int = 53, timeout: int = 3) -> bool:
    """
    Check if internet connection is active.

    Args:
        host (str): Host to connect to for verifying internet connectivity.
        port (int): The port to use for the connection.
        timeout (int): The timeout duration for the connection.

    Returns:
        bool: True if internet connection is active, False otherwise.
    """
    try:
        socket.setdefaulttimeout(timeout)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, port))
        return True
    except Exception as ex:
        logging.info(f"An error occurred: {ex}")
        return False


def wait_network_connection() -> bool:
    """
    Wait for network connection to become active.

    Returns:
        bool: True if internet connections is active, False otherwise.
    """
    internet_connected = check_internet_connection()
    seconds_passed = 0

    while (seconds_passed < TIME_WAIT_INITIAL) and not internet_connected:
        internet_connected = check_internet_connection()
        seconds_passed = seconds_passed + 1
        time.sleep(1)

    return internet_connected


def start_wait_service() -> None:
    """
    Start the service and wait for it to exit.
    """
    while check_service_status(SERVICE_NAME) == 'active':
        stop_service(SERVICE_NAME)
        time.sleep(1)

    start_service(SERVICE_NAME)
    time.sleep(10)
    logging.info("Waiting for service to exit.")

    while check_service_status(SERVICE_NAME) == 'active':
        time.sleep(1)
    logging.info("Service exited.")


def create_status_file(file_name: str) -> str:
    file_path = os.path.join(TEMP_FOLDER_PATH, file_name)
    try:
        with open(file_path, 'x'):
            logging.info(f"File {file_path} created.")
    except FileExistsError:
        logging.info(f"File {file_path} already exists.")
    return file_path


def main() -> None:
    """
    Main function to handle network connectivity and service management

    Function will check for a default connection on boot. If a connection 
    is found, it starts the Flask application for 10 minutes giving the user
    a chance to change it if they wish. If no connection is found it will wait
    for the user to connect via a WiFi hotspot.

    """
    logging.info(
        f"Checking for default internet connection. Timeout: {TIME_WAIT_INITIAL}s.")

    # check for initial network connection
    if wait_network_connection():
        logging.info(f"Device is connected to WiFi and has internet.")

        # retrieve device serial number and configure hostname
        serial_number = get_serial_number()
        serial_last_3 = serial_number[-3:]
        reconfig_hostname = f"telosair-duet-{serial_last_3}"

        subprocess.run(["hostnamectl", "set-hostname", reconfig_hostname])
        subprocess.run(["systemctl", "restart", "avahi-daemon"])

        # create status file indicating connection
        create_status_file(CONNECTED_FLAG)

        # start the Flask application service
        start_service("wifi-app.service")

        # Monitor the Flask service for the duration of HOTSPOT_INACTIVE
        seconds_passed = 0
        while (seconds_passed < HOTSPOT_INACTIVE) and (check_service_status("wifi-app.service") == 'active') == True:
            seconds_passed = seconds_passed + 1
            time.sleep(1)

        # stop the Flask service after timeout
        stop_service("wifi-app.service")
        logging.info(
            f"Service stopped after {HOTSPOT_INACTIVE} seconds of inactivity.")

        # hostname with serial number
        post_config_hostname = f"telosair-duet-{serial_number}"
        subprocess.run(["hostnamectl", "set-hostname", post_config_hostname])
        subprocess.run(["systemctl", "restart", "avahi-daemon"])

        # create status file indicating completion of network configuration
        create_status_file(DONE_NET_CONFIG_FLAG)
        os._exit(0)
    else:
        logging.info(
            f"WiFi could not be connected by default. Waiting for user connect via WiFi hotspot.")

        # Create status file indicating no connection
        create_status_file(NO_CONNECTION_FLAG)

        # continuously wait for user to connect via WiFi hotspot
        while True:
            start_wait_service()

            if wait_network_connection():
                logging.info("WiFi successfully connected.")
                create_status_file(DONE_NET_CONFIG_FLAG)
                os._exit(0)
            else:
                logging.info(
                    "WiFi was connected but failed to gain internet access.")


if __name__ == "__main__":
    main()
