import unittest
from unittest.mock import patch, MagicMock, call
from ensure_wifi import check_internet_connection, wait_network_connection, start_wait_service, main


class TestEnsureWifi(unittest.TestCase):
    def setUp(self) -> None:
        return super().setUp()

    @patch('ensureWifi.socket.socket')
    def test_check_internet_connection(self, mock_socket):
        # This tests the check_internet_connection function.
        # Uses unittest.mock.patch decorator to replace socket.socket with a mock object
        mock_conn = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_conn
        self.assertTrue(check_internet_connection())

    @patch('ensureWifi.check_wifi_connection')
    @patch('ensureWifi.check_internet_connection')
    def test_wait_network_connection(self, mock_check_internet_connection):
        # This tests the wait_network_connection function.
        # It patches check_wifi_connection and check_internet_connection
        # to simulate network state changes.
        mock_check_internet_connection.side_effect = [False, True]

        result = wait_network_connection()

        # Assert that the function returns True after checking the network state multiple times
        self.assertTrue(result)
        self.assertEqual(mock_check_internet_connection.call_count, 2)

    @patch('ensureWifi.time.sleep', return_value=None)
    @patch('ensureWifi.check_service_status')
    @patch('ensureWifi.stop_service')
    @patch('ensureWifi.start_service')
    def test_start_wait_service(self, mock_start_service, mock_stop_service,
                                mock_check_service_status, mock_sleep):
        # This tests the start_wait_service function
        # Patches check_service_status, stop_service, start_service, and time.sleep.
        mock_check_service_status.side_effect = [
            'active', 'active', 'active', 'inactive']

        service_name = 'wifi-config-app.service'

        start_wait_service()

        # Assert start and stop services were called once with the correct parameters
        mock_stop_service.assert_called_once_with(service_name)
        mock_start_service.assert_called_once_with(service_name)

        # Asserts check_service_status was called four times, based on the states mocked by side_effect.
        self.assertEqual(mock_check_service_status.call_count, 4)
        mock_sleep.assert_has_calls([call(10), call(1), call(1)])

    @patch('subprocess.run')
    @patch('subprocess.check_output')
    @patch('ensureWifi.check_service_status')
    @patch('ensureWifi.stop_service')
    @patch('ensureWifi.start_service')
    @patch('ensureWifi.wait_network_connection')
    def test_main_function_connected(self, mock_wait_network_connection,
                                     mock_start_service, mock_stop_service, mock_check_service_status,
                                     mock_check_output, mock_subprocess_run):
        # Tests the main function when the network is connected.
        # Patches wait_network_connection, start_service, stop_service, check_service_status,
        # check_output, and subprocess.run
        mock_wait_network_connection.side_effect = [True]
        mock_check_service_status.side_effect = ['active', 'inactive']
        mock_check_output.return_value = b'10000000686c2eb5\n'

        main()

        # Asserts checking that services were properly started/stopped and hostname commands were properly called.
        mock_start_service.assert_called_once_with("wifi-app.service")
        mock_stop_service.assert_called_once_with("wifi-app.service")
        mock_check_output.assert_called_once_with(
            "cat /proc/cpuinfo | grep Serial | awk '{print $NF}'", shell=True)
        mock_subprocess_run.assert_has_calls([
            call(["hostnamectl", "set-hostname", "telosair-duet-10000000686c2eb5"]),
            call(["systemctl", "restart", "avahi-daemon"])
        ])

    @patch('ensureWifi.start_wait_service')
    @patch('ensureWifi.wait_network_connection')
    def test_main_function_not_connected(self, mock_wait_network_connection, mock_start_wait_service):
        # Tests the main function when the network is not connected.
        # Patches wait_network_connection and start_wait_service.
        mock_wait_network_connection.side_effect = [False, True]

        with self.assertRaises(SystemExit):
            main()

        mock_start_wait_service.assert_called_with()


if __name__ == '__main__':
    unittest.main()
