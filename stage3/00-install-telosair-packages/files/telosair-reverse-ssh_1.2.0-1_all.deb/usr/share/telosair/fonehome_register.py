try:
  import time
  import requests
  import json
  import os

  time.sleep(10)

  def get_sn():
    f = open('/proc/cpuinfo','r')
    for line in f:
      if 'Serial' in line:
        return line[10:26]
    return '10000'

  def get_port(serial_num):
    response = requests.post('https://staging.potsdamsensors.com/gateway-port', json={'serial_num': serial_num})
    if response.status_code == 200:
      d = json.loads(response.text)
      return d['port']
    else:
      return 10000

  lines = list(open('/etc/fonehome/fonehome.conf', 'r+'))
  print(lines)

  sn = get_sn()
  port = get_port(sn)
  reboot = False

  file = open('/etc/fonehome/fonehome.conf', 'w+')
  for line in lines:
    if 'SSH_FLAGS' in line:
      reboot = '-R10000:' in line
      file.write(f"SSH_FLAGS='-R{port}:localhost:22'\n")
    else:
      file.write(line)

  file.close()

  if reboot:
    print("Rebooting in 30s...")
    time.sleep(30)
    os.system('sudo reboot')

  f = open('./log.txt','a')
  f.write(f'{time.time()} success!\n')
  f.close()

except Exception as e:
  f = open('./log.txt','a')
  f.write(f'{time.time()} {e}\n')
  f.close()
